int currentIndex = 0;
List<String> sentences = [
  "Meet up with ongoing Music shows with your favorite artist",
  "Meet up with ongoing Music shows with your favorite artist",
  "Meet up with ongoing Music shows with your favorite artist",
];
