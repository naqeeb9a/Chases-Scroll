class AppKeys {
  static const String token = "token";
  static const String firstInstall = "firstInstall";
}
