import 'package:flutter/material.dart';
import 'package:flutter_sizer/flutter_sizer.dart';

heightSpace(double height) => SizedBox(height: height.h);
widthSpace(double width) => SizedBox(width: width.w);
